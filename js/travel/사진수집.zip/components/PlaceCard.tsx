import React from 'react';
import { Place, PlaceCategory } from '../types';
import { Camera, MapPin, ShoppingBag, Utensils, Loader2, Download } from 'lucide-react';

interface PlaceCardProps {
  place: Place;
  onGenerate: (id: string) => void;
  region: string;
}

const CategoryIcon = ({ category }: { category: PlaceCategory }) => {
  switch (category) {
    case PlaceCategory.RESTAURANT: return <Utensils className="w-4 h-4" />;
    case PlaceCategory.SHOPPING: return <ShoppingBag className="w-4 h-4" />;
    case PlaceCategory.SIGHTSEEING:
    case PlaceCategory.TOURIST_ATTRACTION: return <Camera className="w-4 h-4" />;
    default: return <MapPin className="w-4 h-4" />;
  }
};

const PlaceCard: React.FC<PlaceCardProps> = ({ place, onGenerate, region }) => {
  const isGenerating = place.status === 'generating';
  const hasImages = place.generatedImages?.length > 0;
  const foods = place.foods || [];

  const handleDownload = (imageUrl: string, index: number) => {
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = `${region}_${place.name.replace(/\s+/g, '_')}_${index + 1}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden flex flex-col h-full transition-all hover:shadow-md">
      {/* Header */}
      <div className="p-5">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-lg font-bold text-slate-800 leading-tight">{place.name}</h3>
          <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium 
            ${place.category === PlaceCategory.RESTAURANT ? 'bg-orange-100 text-orange-700' : 
              place.category === PlaceCategory.SHOPPING ? 'bg-blue-100 text-blue-700' : 
              'bg-emerald-100 text-emerald-700'}`}>
            <CategoryIcon category={place.category} />
            {place.category}
          </span>
        </div>
        <p className="text-slate-600 text-sm mb-3 line-clamp-3">{place.description}</p>
        {foods.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-3">
            {foods.map((food, i) => (
              <span key={i} className="text-xs text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
                {food}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Image Area */}
      <div className="mt-auto bg-slate-50 p-5 border-t border-slate-100">
        {hasImages ? (
          <div className="grid grid-cols-1 gap-3">
             {place.generatedImages.map((img, idx) => (
               <div key={idx} className="relative group rounded-lg overflow-hidden aspect-[4/3] shadow-sm">
                 <img src={img} alt={place.name} className="w-full h-full object-cover" />
                 <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                   <button 
                    onClick={() => handleDownload(img, idx)}
                    className="bg-white text-slate-900 px-3 py-1.5 rounded-full text-xs font-bold flex items-center gap-1 hover:bg-slate-100"
                   >
                     <Download className="w-3 h-3" /> Save
                   </button>
                 </div>
               </div>
             ))}
             {/* Allow generating more if needed, or re-generating */}
             <button
              onClick={() => onGenerate(place.id)}
              disabled={isGenerating}
              className="text-xs text-slate-500 hover:text-indigo-600 underline text-center w-full mt-2"
            >
              {isGenerating ? 'Generating variation...' : 'Generate another variation'}
            </button>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-6 text-center">
             <div className="bg-indigo-50 p-3 rounded-full mb-3">
               <Camera className="w-6 h-6 text-indigo-400" />
             </div>
             <p className="text-sm text-slate-500 mb-4">No photos yet.</p>
             <button 
              onClick={() => onGenerate(place.id)}
              disabled={isGenerating}
              className="w-full py-2 px-4 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-300 text-white rounded-lg text-sm font-medium transition-colors flex items-center justify-center gap-2"
             >
               {isGenerating ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Generate "Copyright-Free" Photo'}
             </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default PlaceCard;
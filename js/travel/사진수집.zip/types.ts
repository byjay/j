export enum PlaceCategory {
  RESTAURANT = 'Restaurant',
  SIGHTSEEING = 'Sightseeing',
  SHOPPING = 'Shopping',
  TOURIST_ATTRACTION = 'Tourist Attraction',
  OTHER = 'Other'
}

export interface Place {
  id: string;
  name: string;
  category: PlaceCategory;
  description: string;
  foods: string[];
  generatedImages: string[];
  status: 'idle' | 'generating' | 'completed' | 'failed';
}

export interface SearchState {
  isSearching: boolean;
  progress: string;
  error: string | null;
}


import { Place, PlaceCategory } from "../types";

// Helper to map raw types to PlaceCategory
const mapCategory = (type: string): PlaceCategory => {
  switch (type) {
    case 'food': return PlaceCategory.RESTAURANT;
    case 'shopping': return PlaceCategory.SHOPPING;
    case 'spot': return PlaceCategory.SIGHTSEEING;
    case 'hotel': return PlaceCategory.OTHER; // Or treat as SIGHTSEEING for photo purposes
    case 'transport': return PlaceCategory.OTHER;
    default: return PlaceCategory.TOURIST_ATTRACTION;
  }
};

// Raw data extraction from provided context
const RAW_DATA: Record<string, any[]> = {
  "fukuoka": [
    { name: "Canal City Hakata", type: "spot", desc: "Large shopping and entertainment complex with a canal running through it." },
    { name: "Tenjin Underground Shopping Center", type: "spot", desc: "Atmospheric underground shopping street with European style architecture." },
    { name: "Hakata Hankyu", type: "shopping", desc: "Major department store at Hakata Station." },
    { name: "Daimaru Fukuoka Tenjin", type: "shopping", desc: "Luxury department store in Tenjin." },
    { name: "Iwataya Main Store", type: "shopping", desc: "Oldest department store in Tenjin." },
    { name: "AMU PLAZA Hakata", type: "shopping", desc: "Shopping complex connected to Hakata Station." },
    { name: "Mitsukoshi Fukuoka", type: "shopping", desc: "High-end department store." },
    { name: "Solaria Plaza", type: "shopping", desc: "Fashion-focused shopping building." },
    { name: "Loft Tenjin", type: "shopping", desc: "Lifestyle and variety goods store." },
    { name: "Don Quijote Tenjin", type: "shopping", desc: "Discount store open 24/7." },
    { name: "Parco Fukuoka", type: "shopping", desc: "Trendy fashion and goods." },
    { name: "Fukuoka Tower", type: "spot", desc: "Iconic seaside tower with panoramic views." },
    { name: "Marinoa City Fukuoka", type: "shopping", desc: "Outlet mall with a ferris wheel." },
    { name: "Riverain Center Building", type: "shopping", desc: "Cultural and shopping complex." },
    { name: "LaLaport Fukuoka", type: "shopping", desc: "Shopping mall famous for the giant Gundam statue." },
    { name: "Kawabatadori Shopping Street", type: "shopping", desc: "Traditional shopping arcade." },
    { name: "Tenjin Core", type: "shopping", desc: "Youth fashion complex." },
    { name: "JR Hakata City", type: "shopping", desc: "The station building complex itself." },
    { name: "Hakata Deitos", type: "shopping", desc: "Souvenir and food specialty zone." },
    { name: "Hakata Riverain Mall", type: "shopping", desc: "Upscale shopping mall." },
    { name: "Vivre Tenjin", type: "shopping", desc: "Fashion building." },
    { name: "Yodobashi Camera Hakata", type: "shopping", desc: "Electronics and hobby megastore." },
    { name: "BIC CAMERA Tenjin", type: "shopping", desc: "Electronics retailer." },
    { name: "Ming Hakata", type: "shopping", desc: "Souvenir market inside the station." },
    { name: "MUJI Canal City Hakata", type: "shopping", desc: "Large MUJI store with cafe." },
    { name: "Uniqlo Tenjin", type: "shopping", desc: "Popular casual wear." },
    { name: "GU Tenjin", type: "shopping", desc: "Trendy and affordable fashion." },
    { name: "Animate Fukuoka Tenjin", type: "shopping", desc: "Anime and manga goods." },
    { name: "Ohori Park", type: "spot", desc: "Large park with a pond, popular for relaxation." },
    { name: "Fukuoka Castle Ruins", type: "spot", desc: "Historic castle remains with cherry blossoms." },
    { name: "Kushida Shrine", type: "spot", desc: "Important Shinto shrine, home to Yamakasa festival floats." },
    { name: "Dazaifu Tenmangu Shrine", type: "spot", desc: "Famous shrine dedicated to the god of learning." },
    { name: "Yanagibashi Rengo Market", type: "spot", desc: "Local food market known as 'Hakata's Kitchen'." },
    { name: "Momochi Seaside Park", type: "spot", desc: "Artificial beach park near Fukuoka Tower." },
    { name: "Fukuoka Art Museum", type: "spot", desc: "Art museum located in Ohori Park." },
    { name: "Sumiyoshi Shrine", type: "spot", desc: "One of the oldest shrines in Kyushu." },
    { name: "Nanzoin Temple", type: "spot", desc: "Temple with a giant reclining Buddha statue." },
    { name: "Fukuoka Asian Art Museum", type: "spot", desc: "Museum dedicated to modern Asian art." },
    { name: "Shofukuji Temple", type: "spot", desc: "First Zen temple in Japan." },
    { name: "Tochoji Temple", type: "spot", desc: "Temple with a large wooden Buddha." },
    { name: "Marine World Uminonakamichi", type: "spot", desc: "Large aquarium." },
    { name: "Uminonakamichi Seaside Park", type: "spot", desc: "Expansive park with flowers and animals." },
    { name: "Fukuoka City Zoological Garden", type: "spot", desc: "Zoo and botanical garden." },
    { name: "Hakozaki-gu Shrine", type: "spot", desc: "Major shrine with beautiful grounds." },
    { name: "Rakusuien Garden", type: "spot", desc: "Traditional Japanese garden." },
    { name: "Maizuru Park", type: "spot", desc: "Park surrounding the castle ruins." },
    { name: "Hakata Port Tower", type: "spot", desc: "Port tower with observation deck." },
    { name: "PayPay Dome Fukuoka", type: "spot", desc: "Baseball stadium home to SoftBank Hawks." },
    { name: "Kyushu National Museum", type: "spot", desc: "National museum in Dazaifu." },
    { name: "Fukuoka Anpanman Children's Museum", type: "spot", desc: "Museum for the popular character." },
    { name: "Yusentei Park", type: "spot", desc: "Historic Japanese garden." },
    { name: "Blue Bottle Fukuoka Tenjin", type: "spot", desc: "Famous specialty coffee shop." },
    { name: "Connect Coffee", type: "spot", desc: "Coffee shop with latte art." },
    { name: "SORA COFFEE", type: "spot", desc: "Relaxing coffee spot." },
    { name: "Fuglen Fukuoka", type: "spot", desc: "Nordic style coffee and cocktail bar." },
    { name: "FUK COFFEE", type: "spot", desc: "Travel-themed coffee stand." },
    { name: "FIKA COFFEE", type: "spot", desc: "Cozy cafe." },
    { name: "Cafe Miel", type: "spot", desc: "Coffee shop with a retro vibe." },
    { name: "Coffee County Fukuoka", type: "spot", desc: "Specialty coffee roaster." },
    { name: "Stereo Coffee", type: "spot", desc: "Standing coffee bar with good music." },
    { name: "The Local Coffee Stand Fukuoka", type: "spot", desc: "Coffee stand in a hotel." },
    { name: "NOOICE Tenjin", type: "spot", desc: "Cafe and dining." },
    { name: "MUEN COFFEE", type: "spot", desc: "Minimalist coffee shop." },
    { name: "REC COFFEE", type: "spot", desc: "Renowned specialty coffee shop." },
    { name: "Manu Coffee", type: "spot", desc: "Popular local coffee chain." },
    { name: "White Glass Coffee", type: "spot", desc: "Roastery and bakery." },
    { name: "Hakata Mizutaki Toriden", type: "food", desc: "Famous for Mizutaki (chicken hot pot)." },
    { name: "Hyotan Sushi", type: "food", desc: "Popular sushi restaurant with queues." },
    { name: "Restaurant Sola", type: "food", desc: "French cuisine with a view." },
    { name: "Gyukatsu Motomura", type: "food", desc: "Beef cutlet restaurant." },
    { name: "U.S. Burger", type: "food", desc: "American style burgers." },
    { name: "Chano-ma Fukuoka", type: "food", desc: "Cafe with mattress seating." },
    { name: "Maruni", type: "food", desc: "Japanese set meals." },
    { name: "Hakata Issou", type: "food", desc: "Rich Tonkotsu ramen, 'Cappuccino' broth." },
    { name: "Yoshizuka Unagiya", type: "food", desc: "Famous eel restaurant." },
    { name: "Tempura Hirao", type: "food", desc: "Counter style tempura." },
    { name: "Bills Fukuoka", type: "food", desc: "Famous pancakes and brunch." },
    { name: "Kiwamiya Hambagu", type: "food", desc: "DIY grilled hamburger steak." },
    { name: "Chikae", type: "food", desc: "Fresh seafood and ikizukuri." },
    { name: "Mizutaki Nagano", type: "food", desc: "Traditional Mizutaki restaurant." },
    { name: "Tsukishima Monja Tamatoya", type: "food", desc: "Monjayaki restaurant." },
    { name: "Jiubar Fukuoka", type: "food", desc: "Modern Chinese styling." },
    { name: "Uminoshokudo", type: "food", desc: "Seafood set meals." },
    { name: "The Lively Kitchen", type: "food", desc: "Hotel restaurant." },
    { name: "Miyachiku Steak", type: "food", desc: "Teppanyaki steak." },
    { name: "Ichiran Ramen", type: "food", desc: "Famous tonkotsu ramen chain." },
    { name: "Yatai Nagahama Ramen", type: "food", desc: "Street food stall ramen." },
    { name: "Motsunabe Ooyama", type: "food", desc: "Offal hot pot specialist." },
    { name: "Ganso Hakata Mentaiju", type: "food", desc: "Spicy cod roe specialty." },
    { name: "Hakata Daruma Ramen", type: "food", desc: "Rich pork broth ramen." },
    { name: "Kawayaki Touan", type: "food", desc: "Grilled chicken skin skewers." },
    { name: "Fukuryu Ramen", type: "food", desc: "Ramen shop." },
    { name: "Tenzan Steak", type: "food", desc: "Steak house." },
    { name: "Hakata Robata Genshi", type: "food", desc: "Robatayaki grill." },
    { name: "Udon Taira", type: "food", desc: "Hakata udon famous for burdock tempura." },
    { name: "Sushi Koizumi", type: "food", desc: "High-end sushi." },
    { name: "Hakata Tempura Takao", type: "food", desc: "Tempura restaurant." },
    { name: "Ganso Motsunabe Honten", type: "food", desc: "Original Motsunabe shop." },
    { name: "Mentai Shige", type: "food", desc: "Mentaiko dishes." },
    { name: "Yakiniku Jomon", type: "food", desc: "Grilled meat restaurant." },
    { name: "Montan Hakata", type: "spot", desc: "Stylish hostel and lounge." },
    { name: "Yufuin Village", type: "spot", desc: "Charming hot spring town nearby." },
    { name: "Kinrin Lake", type: "spot", desc: "Scenic lake in Yufuin." },
    { name: "Kamado Jigoku", type: "spot", desc: "Cooking Pot Hell hot spring in Beppu." },
  ],
  "osaka": [
    { name: "Kansai International Airport (KIX)", type: "transport", desc: "Gateway to Osaka." },
    { name: "Dotonbori", type: "spot", desc: "Famous nightlife and dining district with Glico Man." },
    { name: "Kani Doraku Dotonbori", type: "food", desc: "Famous crab restaurant with moving sign." },
    { name: "Ichiran Ramen Dotonbori", type: "food", desc: "Famous solo-dining ramen." },
    { name: "Kuromon Market", type: "food", desc: "Food market known as 'Osaka's Kitchen'." },
    { name: "Shinsekai & Tsutenkaku", type: "spot", desc: "Retro district with iconic tower." },
    { name: "Osaka Castle", type: "spot", desc: "Historic castle and park." },
    { name: "Umeda Sky Building", type: "spot", desc: "Floating Garden Observatory." },
    { name: "HEP FIVE Ferris Wheel", type: "spot", desc: "Red ferris wheel on a mall." },
    { name: "Universal Studios Japan", type: "spot", desc: "World-class theme park." },
    { name: "Osaka Aquarium Kaiyukan", type: "spot", desc: "One of the largest aquariums." },
    { name: "Swissotel Nankai Osaka", type: "hotel", desc: "Luxury hotel in Namba." },
    { name: "The Park Front Hotel", type: "hotel", desc: "Hotel facing USJ." },
    { name: "Midosuji Illumination", type: "spot", desc: "Winter light display." },
    { name: "Osaka Castle 3D Mapping", type: "spot", desc: "Projection mapping show." },
    { name: "Kushikatsu Daruma", type: "food", desc: "Famous fried skewer restaurant." },
    { name: "Takoyaki Wanaka", type: "food", desc: "Popular takoyaki stand." },
    { name: "Rikuro Ojisan", type: "food", desc: "Famous jiggly cheesecake." },
    { name: "Harukas 300", type: "spot", desc: "Tallest skyscraper observatory." },
    { name: "Shinsaibashi-suji", type: "shopping", desc: "Long covered shopping arcade." }
  ],
  "tokyo": [
    { name: "Narita International Airport", type: "transport", desc: "Main international gateway." },
    { name: "Haneda Airport", type: "transport", desc: "Convenient city airport." },
    { name: "Shibuya Sky", type: "spot", desc: "Open-air observation deck." },
    { name: "Shinjuku Gyoen", type: "spot", desc: "Large park and garden." },
    { name: "Omoide Yokocho", type: "food", desc: "Memory Lane, yakitori alley." },
    { name: "Shibuya Blue Cave", type: "spot", desc: "Winter illumination event." },
    { name: "Harajuku Takeshita Street", type: "shop", desc: "Youth fashion and crepes." },
    { name: "Meiji Jingu", type: "spot", desc: "Forested Shinto shrine." },
    { name: "Sensoji", type: "spot", desc: "Oldest temple in Tokyo, Asakusa." },
    { name: "Tokyo Skytree", type: "spot", desc: "Tallest tower in Japan." },
    { name: "Akihabara Electric Town", type: "shop", desc: "Hub for anime and electronics." },
    { name: "Ueno Park", type: "spot", desc: "Park with museums and zoo." },
    { name: "Monja Street", type: "food", desc: "Street famous for Monjayaki." },
    { name: "Ginza Six", type: "shop", desc: "Luxury shopping complex." },
    { name: "Roppongi Hills Illumination", type: "spot", desc: "Winter lights view of Tokyo Tower." },
    { name: "Tsukiji Outer Market", type: "food", desc: "Fresh seafood and street food." },
    { name: "teamLab Planets", type: "spot", desc: "Immersive digital art museum." },
    { name: "Odaiba Gundam", type: "spot", desc: "Life-sized transforming statue." },
    { name: "Tokyo Disney Resort", type: "spot", desc: "Disney Land and Sea." },
    { name: "Hotel Gracery Shinjuku", type: "hotel", desc: "Godzilla hotel." },
    { name: "The Prince Park Tower", type: "hotel", desc: "Luxury hotel near Tokyo Tower." }
  ],
  "sapporo": [
    { name: "New Chitose Airport", type: "transport", desc: "Airport with ramen street and onsen." },
    { name: "Sapporo Beer Museum", type: "spot", desc: "Red brick museum with tastings." },
    { name: "Odori Park", type: "spot", desc: "Central park, site of Snow Festival." },
    { name: "Sapporo TV Tower", type: "spot", desc: "Tower overlooking Odori Park." },
    { name: "Susukino", type: "spot", desc: "Major entertainment district." },
    { name: "Shiroi Koibito Park", type: "spot", desc: "Chocolate factory theme park." },
    { name: "Otaru Canal", type: "spot", desc: "Historic canal in nearby Otaru." },
    { name: "Otaru Music Box Museum", type: "spot", desc: "Historic building with music boxes." },
    { name: "Biei Patchwork Road", type: "spot", desc: "Scenic rural drive." },
    { name: "Blue Pond (Aoiike)", type: "spot", desc: "Famous blue pond in Biei." },
    { name: "Nijo Market", type: "food", desc: "Fresh seafood market." },
    { name: "Soup Curry Garaku", type: "food", desc: "Famous soup curry shop." },
    { name: "Genghis Khan Daruma", type: "food", desc: "Grilled lamb specialty." }
  ],
  "kyoto": [
    { name: "Kansai Airport", type: "transport", desc: "Gateway to Kansai." },
    { name: "Hotel Granvia Kyoto", type: "hotel", desc: "Hotel inside Kyoto Station." },
    { name: "Gion & Pontocho", type: "spot", desc: "Geisha district and dining alley." },
    { name: "Kiyomizu-dera", type: "spot", desc: "Iconic wooden temple on hillside." },
    { name: "Fushimi Inari Taisha", type: "spot", desc: "Shrine with thousands of torii gates." },
    { name: "Arashiyama Bamboo Grove", type: "spot", desc: "Scenic bamboo forest." },
    { name: "Kinkaku-ji", type: "spot", desc: "Golden Pavilion." },
    { name: "Nishiki Market", type: "food", desc: "Kyoto's Kitchen." },
    { name: "Nijo Castle", type: "spot", desc: "Shogun's residence." },
    { name: "Kyoto Tower", type: "spot", desc: "Observation tower near station." }
  ],
  "nagoya": [
    { name: "Nagoya Castle", type: "spot", desc: "Castle with golden dolphins." },
    { name: "Chubu Electric Power MIRAI TOWER", type: "spot", desc: "TV Tower in Sakae." },
    { name: "Atsuta Jingu", type: "spot", desc: "Important Shinto shrine." },
    { name: "Ghibli Park", type: "spot", desc: "Theme park for Studio Ghibli." },
    { name: "Legoland Japan", type: "spot", desc: "Lego theme park." },
    { name: "Osu Kannon", type: "spot", desc: "Temple and shopping arcade." },
    { name: "Hitsumabushi Bincho", type: "food", desc: "Eel on rice specialist." },
    { name: "Komeda's Coffee", type: "food", desc: "Famous Nagoya cafe chain." },
    { name: "Toyota Commemorative Museum", type: "spot", desc: "Industry and technology museum." }
  ],
  "okinawa": [
    { name: "Churaumi Aquarium", type: "spot", desc: "Massive tank with whale sharks." },
    { name: "Kouri Bridge", type: "spot", desc: "Scenic bridge over blue water." },
    { name: "American Village", type: "spot", desc: "Shopping and entertainment complex." },
    { name: "Manzamo", type: "spot", desc: "Scenic cliff looking like an elephant trunk." },
    { name: "Kokusai Dori", type: "spot", desc: "Main shopping street in Naha." },
    { name: "Umikaji Terrace", type: "spot", desc: "White terrace shops by the sea." },
    { name: "Shurijo Castle Park", type: "spot", desc: "Ryukyu kingdom castle." },
    { name: "Cape Manza", type: "spot", desc: "Scenic coastal view." },
    { name: "Blue Seal Ice Cream", type: "food", desc: "Okinawan ice cream." },
    { name: "Jack's Steak House", type: "food", desc: "American style steak." }
  ],
  "kobe": [
    { name: "Kitano Ijinkan", type: "spot", desc: "District of foreign merchants' houses." },
    { name: "Kobe Beef Steakland", type: "food", desc: "Famous Kobe beef restaurant." },
    { name: "Nunobiki Herb Gardens", type: "spot", desc: "Herb garden with ropeway." },
    { name: "Arima Onsen", type: "spot", desc: "Famous hot spring town." },
    { name: "Kobe Harborland", type: "spot", desc: "Shopping and entertainment by the port." },
    { name: "Meriken Park", type: "spot", desc: "Waterfront park with tower." },
    { name: "Nankinmachi", type: "food", desc: "Kobe Chinatown." }
  ],
  "nara": [
    { name: "Nara Park", type: "spot", desc: "Park with free-roaming deer." },
    { name: "Todai-ji", type: "spot", desc: "Temple with giant Buddha." },
    { name: "Nakatanidou", type: "food", desc: "Famous mochi pounding shop." },
    { name: "Kasuga Taisha", type: "spot", desc: "Shrine with many lanterns." },
    { name: "Higashimuki Shopping Street", type: "shop", desc: "Covered arcade." },
    { name: "Kofukuji", type: "spot", desc: "Temple with five-story pagoda." }
  ],
  "yokohama": [
    { name: "Minato Mirai 21", type: "spot", desc: "Futuristic harbor area." },
    { name: "Yokohama Chinatown", type: "food", desc: "Largest Chinatown in Japan." },
    { name: "Cup Noodles Museum", type: "spot", desc: "Interactive instant noodle museum." },
    { name: "Yamashita Park", type: "spot", desc: "Seaside park." },
    { name: "Yokohama Red Brick Warehouse", type: "spot", desc: "Shopping in historic buildings." },
    { name: "Cosmo Clock 21", type: "spot", desc: "Large ferris wheel." },
    { name: "Shin-Yokohama Ramen Museum", type: "food", desc: "Ramen food court and history." }
  ],
  "nikko": [
    { name: "Nikko Toshogu", type: "spot", desc: "Lavish shrine and mausoleum." },
    { name: "Kegon Falls", type: "spot", desc: "High waterfall." },
    { name: "Lake Chuzenji", type: "spot", desc: "Scenic lake in mountains." },
    { name: "Edo Wonderland", type: "spot", desc: "Historical theme park." },
    { name: "Shinkyo Bridge", type: "spot", desc: "Sacred red bridge." }
  ],
  "sendai": [
    { name: "Zuihoden", type: "spot", desc: "Mausoleum of Date Masamune." },
    { name: "Matsushima", type: "spot", desc: "One of Japan's three best views." },
    { name: "Gyutan Street", type: "food", desc: "Beef tongue restaurants in station." },
    { name: "Sendai Castle Ruins", type: "spot", desc: "Site of Aoba Castle." },
    { name: "Jozenji-dori", type: "spot", desc: "Tree-lined avenue." }
  ],
  "kanazawa": [
    { name: "Kenrokuen", type: "spot", desc: "One of Japan's three best gardens." },
    { name: "Higashi Chaya District", type: "spot", desc: "Traditional teahouse district." },
    { name: "21st Century Museum of Contemporary Art", type: "spot", desc: "Modern art museum." },
    { name: "Omicho Market", type: "food", desc: "Fresh food market." },
    { name: "Kanazawa Castle", type: "spot", desc: "Restored castle and park." }
  ],
  "nagasaki": [
    { name: "Glover Garden", type: "spot", desc: "Western style hillside garden." },
    { name: "Mt. Inasa", type: "spot", desc: "Mountain with spectacular night view." },
    { name: "Nagasaki Peace Park", type: "spot", desc: "Park commemorating atomic bombing." },
    { name: "Shikairo", type: "food", desc: "Birthplace of Champon noodles." },
    { name: "Meganebashi", type: "spot", desc: "Spectacles Bridge." },
    { name: "Gunkanjima", type: "spot", desc: "Abandoned island (Battleship Island)." }
  ],
  "hakone": [
    { name: "Hakone Open-Air Museum", type: "spot", desc: "Outdoor sculpture park." },
    { name: "Owakudani", type: "spot", desc: "Active volcanic valley." },
    { name: "Lake Ashi", type: "spot", desc: "Crater lake with Mt Fuji view." },
    { name: "Hakone Shrine", type: "spot", desc: "Shrine with torii in the water." },
    { name: "Yunessun", type: "spot", desc: "Hot spring theme park." }
  ],
  "hiroshima": [
    { name: "Peace Memorial Park", type: "spot", desc: "Memorial to atomic bomb victims." },
    { name: "Miyajima", type: "spot", desc: "Island with floating torii gate." },
    { name: "Okonomimura", type: "food", desc: "Building full of okonomiyaki stalls." },
    { name: "Shukkeien", type: "spot", desc: "Historic Japanese garden." },
    { name: "Hondori", type: "shop", desc: "Covered shopping arcade." }
  ]
};

export const getPredefinedPlaces = (region: string): Place[] | null => {
  const normalizedRegion = region.toLowerCase().trim();
  const placesData = RAW_DATA[normalizedRegion];

  if (!placesData) return null;

  return placesData.map(p => ({
    id: crypto.randomUUID(),
    name: p.name,
    category: mapCategory(p.type),
    description: p.desc,
    foods: p.type === 'food' ? [p.desc] : [], // Simple fallback for foods
    generatedImages: [],
    status: 'idle'
  }));
};

import React, { useState, useCallback, useRef } from 'react';
import { Search, Map, Loader2, Sparkles, AlertCircle, Download, Play, StopCircle, MapPin } from 'lucide-react';
import { ensureApiKey, searchPlacesInRegion, generatePlaceImage } from './services/geminiService';
import { Place, SearchState } from './types';
import PlaceCard from './components/PlaceCard';

// Cities extracted from the user's provided data
const PRESET_CITIES = [
  "Fukuoka", "Osaka", "Tokyo", "Sapporo", 
  "Kyoto", "Nagoya", "Okinawa", "Kobe", 
  "Nara", "Yokohama", "Nikko", "Sendai", 
  "Kanazawa", "Nagasaki", "Hakone", "Hiroshima"
];

export default function App() {
  const [region, setRegion] = useState('');
  const [places, setPlaces] = useState<Place[]>([]);
  const [searchState, setSearchState] = useState<SearchState>({
    isSearching: false,
    progress: '',
    error: null,
  });
  
  const [isBulkProcessing, setIsBulkProcessing] = useState(false);
  const abortControllerRef = useRef<boolean>(false);

  // Core search logic
  const executeSearch = async (targetRegion: string) => {
    if (!targetRegion.trim()) return;

    // Update input field visually if triggered by button
    setRegion(targetRegion);

    setSearchState({ isSearching: true, progress: 'Initializing...', error: null });
    setPlaces([]); // Clear previous results
    
    try {
      const hasKey = await ensureApiKey();
      if (!hasKey) {
        setSearchState({ isSearching: false, progress: '', error: 'API Key selection cancelled.' });
        return;
      }

      setSearchState({ isSearching: true, progress: `Searching for top 100 spots in ${targetRegion} (Including verified local spots & AI suggestions)...`, error: null });
      
      const results = await searchPlacesInRegion(targetRegion);
      
      const newPlaces: Place[] = results.map((p) => ({
        ...p,
        id: crypto.randomUUID(),
        generatedImages: [],
        status: 'idle'
      }));

      setPlaces(newPlaces);
      setSearchState({ isSearching: false, progress: '', error: null });

    } catch (err: any) {
      console.error(err);
      setSearchState({ 
        isSearching: false, 
        progress: '', 
        error: err.message || 'Failed to find places. Please try again.' 
      });
    }
  };

  // Handle form submit
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    executeSearch(region);
  };

  // Handle preset button click
  const handlePresetClick = (city: string) => {
    if (searchState.isSearching || isBulkProcessing) return;
    executeSearch(city);
  };

  // Handle image generation for a specific place
  const handleGenerateImage = useCallback(async (placeId: string, isBulk = false): Promise<boolean> => {
    let placeIndex = -1;
    setPlaces(currentPlaces => {
      placeIndex = currentPlaces.findIndex(p => p.id === placeId);
      if (placeIndex === -1) return currentPlaces;
      
      const newPlaces = [...currentPlaces];
      newPlaces[placeIndex] = { ...newPlaces[placeIndex], status: 'generating' };
      return newPlaces;
    });

    if (placeIndex === -1) return false;

    try {
      const currentPlace = places.find(p => p.id === placeId);
      if (!currentPlace) return false;

      await ensureApiKey(); 
      
      // Use the place name and region for generation. 
      // Note: `region` state might have changed if user typed, but usually fine.
      // Better to use the region from when search happened, but simplistic here.
      const imageUrl = await generatePlaceImage(currentPlace, region); 
      
      setPlaces(prev => {
        const index = prev.findIndex(p => p.id === placeId);
        if (index === -1) return prev;
        const copy = [...prev];
        copy[index] = {
          ...copy[index],
          generatedImages: [...copy[index].generatedImages, imageUrl],
          status: 'completed'
        };
        return copy;
      });
      return true;

    } catch (error) {
      console.error(error);
      setPlaces(prev => {
        const index = prev.findIndex(p => p.id === placeId);
        if (index === -1) return prev;
        const copy = [...prev];
        copy[index] = { ...copy[index], status: 'failed' };
        return copy;
      });
      if (!isBulk) alert(`Failed to generate image. Please try again.`);
      return false;
    }
  }, [places, region]);

  // Bulk generate logic
  const handleBulkGenerate = async () => {
    if (isBulkProcessing) {
      abortControllerRef.current = true;
      setIsBulkProcessing(false);
      return;
    }

    const pendingPlaces = places.filter(p => p.generatedImages.length === 0);
    if (pendingPlaces.length === 0) {
      alert("All places have images! (Or list is empty)");
      return;
    }

    setIsBulkProcessing(true);
    abortControllerRef.current = false;

    const BATCH_SIZE = 30;
    const COOLDOWN_SECONDS = 60;
    let processedInBatch = 0;

    for (let i = 0; i < pendingPlaces.length; i++) {
      if (abortControllerRef.current) break;

      if (processedInBatch >= BATCH_SIZE) {
        for (let t = COOLDOWN_SECONDS; t > 0; t--) {
           if (abortControllerRef.current) break;
           setSearchState(prev => ({ 
             ...prev, 
             progress: `Batch Limit Reached (30 items). Cooling down for API safety: ${t}s remaining...` 
           }));
           await new Promise(resolve => setTimeout(resolve, 1000));
        }
        processedInBatch = 0;
      }

      const place = pendingPlaces[i];
      const element = document.getElementById(`place-${place.id}`);
      if (element) element.scrollIntoView({ behavior: 'smooth', block: 'center' });

      setSearchState(prev => ({ 
        ...prev, 
        progress: `Generating ${i + 1}/${pendingPlaces.length}: ${place.name}` 
      }));

      await handleGenerateImage(place.id, true);
      processedInBatch++;
      
      if (i < pendingPlaces.length - 1) {
        await new Promise(resolve => setTimeout(resolve, 2000));
      }
    }

    setIsBulkProcessing(false);
    setSearchState(prev => ({ ...prev, progress: '', isSearching: false }));
  };

  const handleDownloadAll = async () => {
    const confirmDownload = window.confirm("This will download all generated images. Ensure your browser allows multiple downloads. Continue?");
    if (!confirmDownload) return;

    let count = 0;
    for (const place of places) {
      if (place.generatedImages.length > 0) {
        place.generatedImages.forEach((url, idx) => {
          const link = document.createElement('a');
          link.href = url;
          const safeName = place.name.replace(/[^a-z0-9]/gi, '_').toLowerCase();
          const safeRegion = region.replace(/[^a-z0-9]/gi, '_').toLowerCase();
          link.download = `${safeRegion}_${safeName}_${idx + 1}.png`;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          count++;
        });
        await new Promise(r => setTimeout(r, 250));
      }
    }
    if (count === 0) alert("No images generated yet to download.");
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-20">
      {/* Navbar */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white">
              <Sparkles className="w-5 h-5" />
            </div>
            <span className="font-bold text-xl tracking-tight text-slate-800">TravelGen <span className="text-indigo-600">AI</span></span>
          </div>
          <div className="text-xs text-slate-500 hidden sm:block">
            Gemini 3 Pro Vision (Banana Pro)
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {/* Search Section */}
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h1 className="text-4xl font-extrabold text-slate-900 mb-4 tracking-tight">
            Travel Guide Generator
          </h1>
          <p className="text-lg text-slate-600 mb-8">
            Scrape top 100 travel spots and generate copyright-free "Banana Pro" adapted photos.
          </p>

          {/* Quick City Selectors */}
          <div className="mb-6 flex flex-wrap justify-center gap-2">
            {PRESET_CITIES.map((city) => (
              <button
                key={city}
                onClick={() => handlePresetClick(city)}
                disabled={searchState.isSearching || isBulkProcessing}
                className="px-4 py-1.5 bg-white border border-slate-200 text-slate-600 rounded-full text-sm font-medium hover:bg-indigo-50 hover:border-indigo-200 hover:text-indigo-600 transition-all disabled:opacity-50 shadow-sm"
              >
                {city}
              </button>
            ))}
          </div>

          <form onSubmit={handleSearchSubmit} className="relative group">
            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
              <Map className="h-5 w-5 text-slate-400 group-focus-within:text-indigo-500 transition-colors" />
            </div>
            <input
              type="text"
              value={region}
              onChange={(e) => setRegion(e.target.value)}
              placeholder="Or enter any region manually..."
              className="block w-full pl-12 pr-4 py-4 bg-white border border-slate-200 rounded-2xl shadow-sm placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all text-lg"
              disabled={searchState.isSearching || isBulkProcessing}
            />
            <button
              type="submit"
              disabled={searchState.isSearching || !region.trim() || isBulkProcessing}
              className="absolute right-2 top-2 bottom-2 bg-indigo-600 text-white px-6 rounded-xl font-medium hover:bg-indigo-700 disabled:bg-slate-200 disabled:text-slate-400 transition-colors flex items-center gap-2"
            >
              {searchState.isSearching ? <Loader2 className="animate-spin w-5 h-5" /> : <Search className="w-5 h-5" />}
              <span className="hidden sm:inline">{searchState.isSearching ? 'Scraping...' : 'Explore'}</span>
            </button>
          </form>

          {/* Status Messages */}
          {searchState.isSearching && (
            <div className="mt-4 flex items-center justify-center gap-2 text-indigo-600 text-sm animate-pulse font-medium">
               <Loader2 className="w-4 h-4 animate-spin" />
               {searchState.progress}
            </div>
          )}
          {isBulkProcessing && (
             <div className="mt-4 flex items-center justify-center gap-2 text-indigo-600 text-sm bg-indigo-50 py-2 px-4 rounded-full inline-flex animate-pulse">
                <Loader2 className="w-4 h-4 animate-spin" />
                {searchState.progress || 'Processing bulk generation...'}
             </div>
          )}
          {searchState.error && (
            <div className="mt-4 flex items-center justify-center gap-2 text-red-600 text-sm bg-red-50 py-2 px-4 rounded-lg inline-flex">
               <AlertCircle className="w-4 h-4" />
               {searchState.error}
            </div>
          )}
        </div>

        {/* Results Section */}
        {places.length > 0 && (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
            <div className="flex flex-col sm:flex-row items-center justify-between mb-6 gap-4">
              <h2 className="text-2xl font-bold text-slate-800">
                Found Spots in {region} <span className="text-slate-400 text-lg font-normal">({places.length})</span>
              </h2>
              <div className="flex gap-2 w-full sm:w-auto">
                <button 
                  onClick={handleBulkGenerate}
                  className={`flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2 rounded-lg transition-colors font-medium
                    ${isBulkProcessing 
                      ? 'bg-red-50 text-red-600 hover:bg-red-100 border border-red-200' 
                      : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-sm'}`}
                >
                  {isBulkProcessing ? (
                    <>
                      <StopCircle className="w-4 h-4" /> Stop Auto-Gen
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4" /> Auto-Generate All
                    </>
                  )}
                </button>
                
                <button 
                  onClick={handleDownloadAll}
                  disabled={isBulkProcessing}
                  className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2 bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 disabled:opacity-50 rounded-lg transition-colors font-medium shadow-sm"
                >
                  <Download className="w-4 h-4" /> Download All
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {places.map((place) => (
                <div id={`place-${place.id}`} key={place.id}>
                  <PlaceCard 
                    place={place} 
                    onGenerate={(id) => handleGenerateImage(id, false)} 
                    region={region} 
                  />
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Empty State / Initial Instructions */}
        {!searchState.isSearching && places.length === 0 && !searchState.error && (
          <div className="text-center py-20 opacity-50">
             <div className="mx-auto w-24 h-24 bg-slate-200 rounded-full flex items-center justify-center mb-4">
                <MapPin className="w-10 h-10 text-slate-400" />
             </div>
             <p className="text-slate-500">Select a popular city above or search manually.</p>
          </div>
        )}
      </main>
    </div>
  );
}
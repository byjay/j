import { GoogleGenAI, Type, Schema } from "@google/genai";
import { Place, PlaceCategory } from "../types";
import { getPredefinedPlaces } from "../data/predefinedPlaces";

// Helper to manage API Key selection
export const ensureApiKey = async (): Promise<boolean> => {
  if (typeof window !== 'undefined' && (window as any).aistudio) {
    const hasKey = await (window as any).aistudio.hasSelectedApiKey();
    if (!hasKey) {
      const success = await (window as any).aistudio.openSelectKey();
      return success;
    }
    return true;
  }
  return true; // Fallback for environments without the wrapper, assumes env var exists
};

const getClient = () => {
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

export const searchPlacesInRegion = async (region: string): Promise<Omit<Place, 'id' | 'generatedImages' | 'status'>[]> => {
  const ai = getClient();
  const TARGET_TOTAL = 100;
  
  // 1. Check for predefined hardcoded places
  const predefinedPlaces = getPredefinedPlaces(region) || [];
  const existingNames = predefinedPlaces.map(p => p.name);
  const remainingCount = Math.max(0, TARGET_TOTAL - predefinedPlaces.length);

  // If we already have enough (unlikely given the hardcoded lists are ~20), or if user wants full generation
  // But generally we want to mix.
  
  const systemInstruction = `You are a travel expert.
  Your task is to find a massive list of famous travel spots in ${region}.
  
  CRITICAL RULE: The user already has a list of these places: ${JSON.stringify(existingNames)}. 
  DO NOT include these in your output. Find *new* and *different* places.
  
  DISTRIBUTION RULE: The final combined list (including existing ones) needs to be diverse. 
  Since the existing list might be mixed, ensure your *new* suggestions help balance the total to be approx 30% Restaurants/Food and 70% Sightseeing/Shopping.
  
  Scrape information about Restaurants, Sightseeing spots, Shopping areas, and Tourist Attractions.
  For each place, provide a category, a vivid visual description suitable for image generation, and famous foods if it's a restaurant.
  Ensure the names are the official names to ensure accuracy.`;

  const schema: Schema = {
    type: Type.ARRAY,
    items: {
      type: Type.OBJECT,
      properties: {
        name: { type: Type.STRING, description: "Official name of the place" },
        category: { type: Type.STRING, enum: Object.values(PlaceCategory) },
        description: { type: Type.STRING, description: "Detailed visual description for generating a photo" },
        foods: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Famous foods" }
      },
      required: ["name", "category", "description"]
    }
  };

  try {
    // Requesting to fill the gap
    if (remainingCount <= 0) {
        return predefinedPlaces;
    }

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `List ${remainingCount} MORE famous travel spots in ${region}. 
      Do not duplicate: ${existingNames.join(', ')}.
      Include local hidden gems, famous restaurants (ensure about 30% of total are food-related), shopping districts, and landmarks.`,
      config: {
        systemInstruction,
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: schema,
      },
    });

    const text = response.text;
    let newPlaces: Omit<Place, 'id' | 'generatedImages' | 'status'>[] = [];

    if (text) {
      try {
        const parsed = JSON.parse(text);
        
        if (Array.isArray(parsed)) {
          newPlaces = parsed.map((item: any) => ({
            name: item.name || "Unknown Location",
            category: item.category || PlaceCategory.SIGHTSEEING,
            description: item.description || "A famous travel spot.",
            foods: Array.isArray(item.foods) ? item.foods : []
          }));
        } else {
            console.warn("Parsed API response is not an array:", parsed);
        }
      } catch (parseError) {
        console.error("Failed to parse JSON response:", parseError);
      }
    }

    // Combine predefined and new places
    // Remove potential duplicates just in case AI ignored instructions
    const combined: Omit<Place, 'id' | 'generatedImages' | 'status'>[] = [...predefinedPlaces];
    const existingNameSet = new Set(existingNames.map(n => n.toLowerCase()));

    for (const p of newPlaces) {
        if (!existingNameSet.has(p.name.toLowerCase())) {
            combined.push(p);
            existingNameSet.add(p.name.toLowerCase());
        }
    }

    return combined;

  } catch (error) {
    console.error("Error searching places:", error);
    // If API fails, at least return the predefined ones
    if (predefinedPlaces.length > 0) {
        return predefinedPlaces;
    }
    throw error;
  }
};

export const generatePlaceImage = async (place: Place, region: string): Promise<string> => {
  const ai = getClient();
  
  // Safe access to foods
  const foodsList = place.foods || [];
  const foodPrompt = place.category === PlaceCategory.RESTAURANT && foodsList.length > 0 
    ? `Focus on the food: ${foodsList.join(', ')} served in the restaurant's setting.` 
    : '';

  // Prompt engineering for "Banana Pro" (Gemini 3 Pro Image)
  // Focusing on "Copyright-Free Adaptation" by asking for a new artistic interpretation
  const prompt = `Create a stunning, professional travel photograph of ${place.name} in ${region}. 
  Description: ${place.description}. 
  Style: Photorealistic, 4k resolution, cinematic lighting, travel magazine aesthetic.
  Composition: Capture the atmosphere and architecture or landscape beautifully. 
  ${foodPrompt}
  Do not use text overlays. Make it look like a high-end stock photo.`;

  try {
    // Using gemini-3-pro-image-preview for high quality adaptation
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-image-preview',
      contents: {
        parts: [{ text: prompt }],
      },
      config: {
        imageConfig: {
          aspectRatio: "4:3",
          imageSize: "1K"
        }
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    throw new Error("No image data returned");
  } catch (error) {
    console.error(`Error generating image for ${place.name}:`, error);
    throw error;
  }
};